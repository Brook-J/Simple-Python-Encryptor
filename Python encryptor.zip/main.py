def encryptor(message, shift_number):
    encrypted_result = ""
    for char in message:
        ascii_value = ord(char)
        encryption = chr(ascii_value + shift_number)
        encrypted_result = encrypted_result + encryption
    return encrypted_result



user_message = input("Enter a message")
user_shift = int(input("Enter a shift  number"))
print(encryptor(user_message, user_shift))